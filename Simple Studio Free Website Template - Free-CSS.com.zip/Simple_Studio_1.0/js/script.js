$(function(){
	
	// Initialize the gallery
	$('.thumbs a').touchTouch();

});
